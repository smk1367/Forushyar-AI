"""Smart Sales AI backend."""
